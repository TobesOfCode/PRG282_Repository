﻿namespace AddSuperhero
{
    partial class SuperHeroHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAddHero = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnViewSuper = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAddHero
            // 
            this.btnAddHero.Location = new System.Drawing.Point(108, 417);
            this.btnAddHero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAddHero.Name = "btnAddHero";
            this.btnAddHero.Size = new System.Drawing.Size(139, 28);
            this.btnAddHero.TabIndex = 0;
            this.btnAddHero.Text = "Add a Superhero";
            this.btnAddHero.UseVisualStyleBackColor = true;
            this.btnAddHero.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(272, 79);
            this.lblWelcome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(474, 95);
            this.lblWelcome.TabIndex = 1;
            this.lblWelcome.Text = "WELCOME";
            // 
            // btnViewSuper
            // 
            this.btnViewSuper.Location = new System.Drawing.Point(357, 417);
            this.btnViewSuper.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnViewSuper.Name = "btnViewSuper";
            this.btnViewSuper.Size = new System.Drawing.Size(100, 28);
            this.btnViewSuper.TabIndex = 2;
            this.btnViewSuper.Text = "button1";
            this.btnViewSuper.UseVisualStyleBackColor = true;
            this.btnViewSuper.Click += new System.EventHandler(this.btnViewSuper_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(546, 417);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 3;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // SuperHeroHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnViewSuper);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.btnAddHero);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "SuperHeroHome";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.SuperHeroHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAddHero;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnViewSuper;
        private System.Windows.Forms.Button btnUpdate;
    }
}