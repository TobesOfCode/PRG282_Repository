﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace AddSuperhero
{
    public partial class Update : Form
    {
        private readonly string filePath = "superheroes.txt";
        private DataTable table;
        private BindingSource bs = new BindingSource();

        public Update()
        {
            InitializeComponent();

            this.Load += Update_Load;
            dgvUpdate.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvUpdate.ReadOnly = true;
            dgvUpdate.SelectionChanged += dgvUpdate_SelectionChanged;

            btnFind.Click += btnFind_Click;
            btnUpdate.Click += btnUpdate_Click;
        }

        private void Update_Load(object sender, EventArgs e)
        {
            table = new DataTable("Superheroes");
            table.Columns.Add("HeroID");
            table.Columns.Add("Name");
            table.Columns.Add("Age");
            table.Columns.Add("Superpower");
            table.Columns.Add("ExamScore");
            table.Columns.Add("Rank");
            table.Columns.Add("ThreatLevel");

            if (File.Exists(filePath))
            {
                foreach (var line in File.ReadAllLines(filePath))
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var f = line.Split(',');
                    if (f.Length < 5) continue;

                    int age = int.TryParse(f[2], out var a) ? a : 0;
                    int score = int.TryParse(f[4], out var s) ? s : 0;

                    var hero = new AddHero(f[0], f[1], age, f[3], score);
                    table.Rows.Add(hero.HeroID, hero.Name, hero.Age, hero.Superpower,
                                   hero.ExamScore, hero.Rank, hero.ThreatLevel);
                }
            }

            bs.DataSource = table;
            dgvUpdate.DataSource = bs;
            dgvUpdate.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            if (dgvUpdate.Rows.Count > 0) dgvUpdate.Rows[0].Selected = true;
        }

        private void dgvUpdate_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvUpdate.CurrentRow == null) return;

            txtBoxID.Text = dgvUpdate.CurrentRow.Cells["HeroID"].Value?.ToString() ?? "";
            txtBoxName.Text = dgvUpdate.CurrentRow.Cells["Name"].Value?.ToString() ?? "";
            txtBoxAge.Text = dgvUpdate.CurrentRow.Cells["Age"].Value?.ToString() ?? "";
            txtBoxSuperpower.Text = dgvUpdate.CurrentRow.Cells["Superpower"].Value?.ToString() ?? "";
            txtBoxScore.Text = dgvUpdate.CurrentRow.Cells["ExamScore"].Value?.ToString() ?? "";
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            string id = txtBoxID.Text.Trim();
            if (string.IsNullOrWhiteSpace(id))
            {
                MessageBox.Show("Enter a Hero ID to find.");
                return;
            }
            if (dgvUpdate.Rows.Count == 0)
            {
                MessageBox.Show("No data loaded.");
                return;
            }

            foreach (DataGridViewRow row in dgvUpdate.Rows)
            {
                if (row.IsNewRow) continue;
                var cellId = row.Cells["HeroID"].Value?.ToString();
                if (string.Equals(cellId, id, StringComparison.OrdinalIgnoreCase))
                {
                    row.Selected = true;
                    dgvUpdate.CurrentCell = row.Cells["HeroID"];
                    dgvUpdate_SelectionChanged(dgvUpdate, EventArgs.Empty);
                    return;
                }
            }
            MessageBox.Show("Hero ID not found.");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvUpdate.CurrentRow == null)
                {
                    MessageBox.Show("Select a record in the table first.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtBoxID.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxName.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxAge.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxSuperpower.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxScore.Text))
                { MessageBox.Show("Please fill in all fields."); return; }

                if (!int.TryParse(txtBoxAge.Text, out int age) || age <= 0)
                { MessageBox.Show("Age must be a positive number."); return; }

                if (!int.TryParse(txtBoxScore.Text, out int score) || score < 0 || score > 100)
                { MessageBox.Show("Exam score must be 0–100."); return; }

                var updated = new AddHero(
                    txtBoxID.Text.Trim(),
                    txtBoxName.Text.Trim(),
                    age,
                    txtBoxSuperpower.Text.Trim(),
                    score
                );

                int rowIndex = dgvUpdate.CurrentRow.Index;
                DataRow row = table.Rows[rowIndex];

                row["HeroID"] = updated.HeroID;
                row["Name"] = updated.Name;
                row["Age"] = updated.Age.ToString();
                row["Superpower"] = updated.Superpower;
                row["ExamScore"] = updated.ExamScore.ToString();
                row["Rank"] = updated.Rank;
                row["ThreatLevel"] = updated.ThreatLevel;

                WriteWholeTableToFile();

                dgvUpdate.Refresh();
                dgvUpdate.ClearSelection();
                if (rowIndex >= 0 && rowIndex < dgvUpdate.Rows.Count)
                    dgvUpdate.Rows[rowIndex].Selected = true;

                MessageBox.Show("Superhero updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating hero: " + ex.Message);
            }
        }

        private void WriteWholeTableToFile()
        {
            var lines = table.Rows
                             .Cast<DataRow>()
                             .Select(r => string.Join(",",
                                 r["HeroID"],
                                 r["Name"],
                                 r["Age"],
                                 r["Superpower"],
                                 r["ExamScore"],
                                 r["Rank"],
                                 r["ThreatLevel"]))
                             .ToArray();

            File.WriteAllLines(filePath, lines);
        }

        private void dgvUpdate_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            SuperHeroHome home = new SuperHeroHome();
            home.Visible = true;
            this.Hide();
        }
    }
}
