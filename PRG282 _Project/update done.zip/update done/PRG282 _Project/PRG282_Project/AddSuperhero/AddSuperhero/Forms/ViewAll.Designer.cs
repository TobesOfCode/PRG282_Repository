﻿namespace AddSuperhero
{
    partial class ViewAll
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvViewSuperheroes = new System.Windows.Forms.DataGridView();
            this.btnReturn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewSuperheroes)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvViewSuperheroes
            // 
            this.dgvViewSuperheroes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvViewSuperheroes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvViewSuperheroes.Location = new System.Drawing.Point(16, 33);
            this.dgvViewSuperheroes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvViewSuperheroes.Name = "dgvViewSuperheroes";
            this.dgvViewSuperheroes.ReadOnly = true;
            this.dgvViewSuperheroes.RowHeadersWidth = 51;
            this.dgvViewSuperheroes.Size = new System.Drawing.Size(1035, 458);
            this.dgvViewSuperheroes.TabIndex = 0;
            this.dgvViewSuperheroes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvViewSuperheroes_CellContentClick);
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(951, 511);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(100, 28);
            this.btnReturn.TabIndex = 1;
            this.btnReturn.Text = "Back";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // ViewAll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.dgvViewSuperheroes);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ViewAll";
            this.Text = "ViewAll";
            this.Load += new System.EventHandler(this.ViewAll_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewSuperheroes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvViewSuperheroes;
        private System.Windows.Forms.Button btnReturn;
    }
}